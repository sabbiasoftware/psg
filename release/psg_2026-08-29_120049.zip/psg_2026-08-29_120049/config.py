import os
import csv
from common import read_strings, read_dates, HourType


class Config:
    def __init__(self):
        self.Users = read_strings(os.path.join("cfg", "users.txt"), do_strip=True, do_lower=True)
        self.Projects = read_strings(os.path.join("cfg", "projects.txt"), do_lower=True)
        self.Holidays = read_dates(os.path.join("cfg", "holidays.txt"))
        self.Weekends = read_dates(os.path.join("cfg", "weekends.txt"))
        self.Workingdays = read_dates(os.path.join("cfg", "workingdays.txt"))
        self.SpecialProjects = {
            "Approved Absence (H)": HourType.VACATION,
            "Vacations": HourType.VACATION,
            "Sick Leave (H)": HourType.SICK,
            "Medical Leave": HourType.SICK,
            "Public Holiday": HourType.HOLIDAY,
        }

        self.Hotlines = {}
        fnhotlines = os.path.join("cfg", "hotlines.txt")
        if os.path.exists(fnhotlines):
            hotlines = read_strings(fnhotlines, do_strip=True)
            for row in hotlines:
                fields = row.split(",")
                if len(fields) != 2:
                    continue
                hotline = fields[0]
                email = fields[1].lower()
                if email not in self.Hotlines.keys():
                    self.Hotlines[email] = hotline

        self.Rates = {}
        fnrates = os.path.join("cfg", "rates.csv")
        if os.path.exists(fnrates):
            with open(fnrates, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f)
                for row in reader:
                    grade = row["Grade"].strip()
                    rate = row["Rate"].strip()
                    if grade:
                        self.Rates[grade] = rate

        self.UserData = {}
        fnuserdata = os.path.join("cfg", "userdata.csv")
        if os.path.exists(fnuserdata):
            with open(fnuserdata, "r", encoding="utf-8") as f:
                reader = csv.DictReader(f, delimiter="\t")
                for row in reader:
                    email = row["Work Email"].strip()
                    if not email:
                        continue
                    self.UserData[email.lower()] = {
                        "Employment Status": row["Employment Status"],
                        "Reporting to": row["Reporting to"],
                        "Job Title": row["Job Title"],
                        "Global Grade": row["Global Grade"],
                    }
